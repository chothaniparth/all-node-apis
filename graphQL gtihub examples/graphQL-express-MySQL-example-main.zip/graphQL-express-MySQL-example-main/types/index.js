const PostType = require('./Post');
const UserType = require('./User');

module.exports = {
  PostType,
  UserType
}

// Database Configuration
module.exports = db = {
  "DB_HOST": "127.0.0.1",
  "DB_USER": "root",
  "DB_PASSWORD": "YOUR DB PASSWORD",
  "DB_PORT": 3306,
  "DB_DATABASE": "YOUR DB NAME"
};